window.onload()=function () {
    for (key in ['我','選擇測驗項目','個人資料','修改個人資料','選擇練習科目','科目1','科目2','科目3','查詢成績','練習','測驗']) {
        value[key] = localStorage.getItem();
    }
    document.write(`
	
        <div class="homed">
            <p href="{{ url_for('lst') }}" ><input value="#" name="index" />"/" class="homed">個人資料</p>
        </div>
        
        <ul class="menu;sidenav" id="menu">
            <li><a href="{{ url_for('lst') }}" ><input value="#" name="index" />"teacher-personal-information.htm" target="_self">
                個人資料</a></li>
            </li>
			<li><a href="{{ url_for('lst') }}" ><input value="#" name="index" />"teacher-personal-information-change.htm" target="_self">
                修改個人資料</a></li>
            </li>
			<li class="mldropl"><a class="mldrop">題庫與試題</a>
                <div id="mlcon">
                    <a href="{{ url_for('lst') }}" ><input value="#" name="index" />"" target="_self">科目1</a>
					<a href="{{ url_for('lst') }}" ><input value="#" name="index" />"">科目2</a>
					<a href="{{ url_for('lst') }}" ><input value="#" name="index" />"">科目3</a>
                </div>
            </li>
			<li><a href="{{ url_for('lst') }}" ><input value="#" name="index" />'teacher-exam-score.htm' target="_self">
                學生成績</a></li>
            </li>
        </ul>
<div id="user"> </div>
        <br>
    `);}
//拿資料 JSON.parse(localStorage.getItem('itemIndex')

obj = JSON;
for(key in Object.keys(obj)){
    setlocalStorage(obj[key]);
}
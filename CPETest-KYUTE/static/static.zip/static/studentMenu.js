var value = { 'sheetName': '學生', '我': '學生', '選擇測驗項目': '學生', '個人資料': '學生', '修改個人資料': '學生', '選擇練習科目': '學生', '科目1': '學生', '科目2': '學生', '科目3': '學生', '查詢成績': '學生', '練習': '學生', '測驗': '學生' }
document.open();
for (key in ['我', '選擇測驗項目', '個人資料', '修改個人資料', '選擇練習科目', '科目1', '科目2', '科目3', '查詢成績', '練習', '測驗']) {
    value[key] = localStorage.getItem(key);
}
document.write(`
        <div class="homed">
            <p href="{{ url_for('page') }}" "/" class="homed">`+ value[個人資料] + `</p>
        </div>
        
        
        <ul class="menu;sidenav" id="menu">
            <li><a href="{{ url_for('loginSt') }}" >
            `+ value[個人資料] + `</a></li>
            </li>
			<li><a href="{{ url_for('st') }}" ><input value="1" name="index" />"student-personal-information-change.htm" target="_self">
            `+ value[修改個人資料] + `</a></li>
            </li>
			<li class="mldropl"><a class="mldrop">`+ value[選擇練習科目] + `</a>
                <div id="mlcon">
                    <a href="{{ url_for('st') }}" ><input value="201" name="index" target="_blank">`+ value[科目1] + `</a>
					<a href="{{ url_for('st') }}" ><input value="202" name="index" target="_blank">"`+ value[科目2] + `</a>
					<a href="{{ url_for('st') }}" ><input value="203" name="index" target="_blank">`+ value[科目3] + `</a>
                </div>
            </li>
			<li class="mldropl"><a class="mldrop">`+ value[選擇測驗科目] + `</a>
                <div id="mlcon">
                    <a href="{{ url_for('st') }}" ><input value="101" name="index" target="_blank">`+ value[科目1] + `</a>
					<a href="{{ url_for('st') }}" ><input value="102" name="index" target="_blank">`+ value[科目2] + `</a>
					<a href="{{ url_for('st') }}" ><input value="103" name="index" target="_blank">`+ value[科目3] + `</a>
                </div>
            </li>
			<li class="pydropl"><a class="pydrop">`+ value[查詢成績] + `</a>
                <div id="pycon">
                    <a href="{{ url_for('st') }}" ><input value="21" name="index" />` + value[測驗] + `</a>
                </div>
			</li>
        </ul>
    `);
document.close();
alert("QQ")
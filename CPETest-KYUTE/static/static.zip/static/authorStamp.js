document.open();
document.write(`
        <div>
   
		<hr style="margin-top: 50px;"/>
        <div style="text-align: center;min-height: 50px;">
            更新日期:2022年1月8日 02:45
		<br>
			開發人員:蔡凡葦、范植勝、黃姿毓
        </div>
        `);
document.close();

document.open();
document.write(`
    <head>
		<style type="text/css">

            body{
                font-size: 20px;font-family:"monospace";margin: 0px;
            }
            .home{
                text-decoration: none;color:unset
            }
            .homed{
                background-color: #404040;height: 100px;font-size: 50px;color: #E3E3E3;
                text-align:center;line-height:100px;margin: 0px;width: 100%;
            }
            form{
                line-height: 30px;
            }
            .in{
                width:200px;height:25px;
            }          
            .btn {
                border: 2px solid white;
                background-color: white;
                color: black;text-decoration:none;
                padding: 10px 20px;
                font-size: 16px;border-radius: 10px;
                cursor: pointer;border-color: white;
                color: #404040;
            }
            .btn:hover{
                background-color: #F5F5F5;
                color: #404040;
            }
            .btn:active{
                background-color: #F5F5F5;border-color: #F5F5F5;
                color: #404040;
            }
            
            input:focus{
                background-color: #EDEDED;
                color: black;
            }
            input {
                border: 2px solid black;
                background-color: white;
                color: black;text-decoration:none;
                padding: 5px 10px;margin: 5px;
                font-size: 16px;border-radius: 10px;
                cursor: pointer;border-color: #919191;
                color: #919191;
            }
            .bottonbut{
                color: black;
                text-align: center;
                padding:20px 5px;
                text-decoration: none;
                width: auto;cursor: pointer;
            }
            .bottonbut:hover{
                color: #EDEDED;
            }
			table#score {
                margin-top: 20px ;background-color:white;
                border-radius: 10px;
                overflow-x:auto;max-width: 80%;
                
            }
            #score th{
                font-size: 15px;font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                background-color: #7B7B7B;padding:10px;max-width: 100cm;text-align:middle;margin-top: 10px;
                color: white;border-color: #aaaaaa;
            }
            #score td {
                padding:10px;max-width: 100cm;text-align:center;
                text-align:middle;margin-top: 40px;
            }
            #score tr:nth-child(odd){
                padding:10px;max-width: 100cm;
                text-align:middle;margin-top: 40px;background-color: #E0E0E0;
            }
            #score tr:nth-child(1){
                background-color: #000000;color: #eeeeee;text-align:center;
                border-top-left-radius: 10px;border-top-right-radius: 10px;
            }
            #score tr:nth-child(even){
                padding:10px;max-width: 100cm;
                text-align:middle;margin-top: 40px;background-color: white;
            }
            .sub{
                padding: 20px;border: 5px solid;width: 220px; background-color:#a07708;
                display: inline-block;border-radius: 10px;text-align: start;
            }
			#menu {
                list-style-type: none;
                margin-top: -100px;
                padding: 0;
                width: 15%;
                background-color: #404040;
                position: fixed;
                height: 100%;
                overflow: hidden;z-index: 1;
            }
            .menu {
                position: -webkit-sticky; 
                position: sticky;
                top: -2px;
                z-index: 1;
            }
            li a,li div {
                display: block;
                color: white;
                text-align: center;
                padding:15px 15px;
                text-decoration: none;
                width: auto;cursor: pointer;
            }
            ul#menu li {
                float: none;
            }
            li.pydrop{
                display: inline-block;
            }
            li a:hover ,li div:hover  {
                background-color: #333333;color: #4CAF50;
            }
            #pycon , #mlcon{
                display: none;
                position: absolute ;
                background-color: #f9f9f9;
                min-width: 160px;
                box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
                z-index: 4;overflow: visible;
            }
            #pycon a ,#mlcon a{
                color: black;
                padding: 12px 16px;
                text-decoration: none;
                display: block;overflow: visible;
                text-align: left;
            }
            #pycon a:hover ,#mlcon a:hover {
                background-color: #f1f1f1;
            }
			.pydropl:hover #pycon ,.mldropl:hover #mlcon{
                display: block;
            }

            main{
                margin: 10px;justify-content: center;text-align: center;
                margin-left: 15%;margin-right: 15%;align-items: center;
                min-height: 800px;
            }
		</style>
    </head>
	<div id="user"> </div>
    `);
document.close();